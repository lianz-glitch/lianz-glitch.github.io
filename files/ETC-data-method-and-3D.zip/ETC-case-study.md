# ETC: transferable examples (separate from the general-purpose skill)

This case study describes a research workflow reconstructed from an ETC project archive reviewed on October 6, 2026. Historical batch counts below concern their own frozen samples and must not be added together. It does not certify every underlying observation or impose this project's rules on other studies.

## The workflow that emerged

1. **Anchor the population.** CMS model materials defined assignment; a Dartmouth geographic crosswalk linked facilities to markets. These were fixed separately from later source availability.
2. **Build a longitudinal identity spine.** CMS certification and Provider of Services histories, Dialysis Facility Compare, NPPES, and dated state/operator records were reconciled. A re-audit showed that endpoint stock differences missed some facilities that entered and disappeared before the endpoint.
3. **Find measurements, not only listings.** Public renal cost reports supplied treatment activity, training, labor, and finances. Facility reports supplied patient demographics and quality measures. Capability in a registry was kept distinct from actual activity in a cost report.
4. **Work through individual gaps.** Original report versions, alternate dated provider IDs, worksheet coordinates, state plans, inspection records, and facility-specific historical documents were checked. A missing spreadsheet cell sometimes reflected extraction or encoding, rather than unavailable public data.
5. **Reject tempting substitutions.** Later snapshots, shared-parent founding dates, adjacent-suite permits, and overlapping reporting periods did not qualify merely because they reduced missingness.
6. **Release evidence with values.** Candidate patches, source ledgers, coverage diagnostics, and unresolved reasons allowed another run to continue without repeating dead ends.

## Concrete examples

- A historical investment-timing batch raised observed A/B/C milestone coverage from 51 to 76 out of 116 successful independent entrants; a follow-up raised it to 86. These include legal-entity milestones and should not all be called directly observed investment decisions. The records still could not reveal every unrealized idea or establish a national failed-project denominator.
- A September 11 configuration batch added 12 dated station observations. California annual records without the required observation date were preserved separately rather than inserted into a 0-180-day opening-configuration variable.
- A September 30 recovery batch reported 981 newly recovered missing input/financial fields. Of these, 937 depended on explicitly verified electronic-report zero encoding; that does not mean all 937 final aggregate values were zero. The audit required valid original reports, applicable coordinates, and worksheet consistency.
- An October 1 candidate batch reported 803 recovered fields across 506 facility-years: 762 input fields and 41 training fields. It also preserved unresolved report-period and identity conflicts. These counts describe a batch, not the total number of unique recoveries across the project, and candidate acceptance alone does not prove final manuscript adoption.
- A 2025 entrant audit retained unresolved cases even when patient activity was documented. Positive activity in a window spanning two calendar years does not alone identify the first operating year. The current manuscript did not treat this incomplete candidate set as a complete 2025 entry cohort.

## Public source starting points

- [CMS ETC model materials](https://www.cms.gov/priorities/innovation/innovation-models/esrd-treatment-choices-model): policy assignment and institutional definitions.
- [CMS renal cost reports](https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports/renal-facility-265-2011-form): original report records; consult the applicable reporting instructions.
- [CMS Provider of Services](https://data.cms.gov/provider-characteristics/hospitals-and-other-facilities/provider-of-services-file-hospital-non-hospital-facilities): certification and facility histories.
- [CMS Medicare Dialysis Facilities](https://data.cms.gov/quality-of-care/medicare-dialysis-facilities): public facility report releases and dictionaries.
- [Dartmouth supplemental data](https://data.dartmouthatlas.org/supplemental/): geographic crosswalks.

These are discovery links, not permission to use today's release as a historical measurement. The shareable skill contains no private conversation archive, original research data, local usernames, or API credentials. The researcher's separate provenance package records the supporting local reports for the examples.
