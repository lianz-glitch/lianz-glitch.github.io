#!/usr/bin/env python3
"""Project-local index for locating research sessions; never starts research."""
import argparse
import contextlib
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import sys
import unicodedata
import uuid


STATUSES = {"SEARCHING", "VERIFYING", "TOPIC_FOUND", "NOT_FOUND_YET", "BLOCKED"}
SCHEMA = (
    """CREATE TABLE sessions (
        id TEXT PRIMARY KEY, root TEXT UNIQUE NOT NULL, title TEXT NOT NULL,
        interest TEXT NOT NULL, status TEXT NOT NULL,
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""",
    """CREATE TABLE bindings (
        context_id TEXT PRIMARY KEY, session_id TEXT NOT NULL REFERENCES sessions(id),
        updated_at TEXT NOT NULL)""",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def text_value(value, field):
    require(isinstance(value, str) and value.strip(), f"{field} must be nonempty text")
    return value.strip()


def normal(value):
    return " ".join(unicodedata.normalize("NFKC", value).casefold().split())


def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def registry_path(project):
    project = Path(project).resolve()
    require(project.is_dir(), f"Project directory does not exist: {project}")
    return project / "work" / "econ-topic-scout" / "sessions.sqlite3"


@contextlib.contextmanager
def connect(project, write=False, create=False):
    path = registry_path(project)
    if create:
        require(write, "Registry creation requires a write operation")
        path.parent.mkdir(parents=True, exist_ok=True)
    else:
        require(path.is_file(), f"Registry not found: {path}; inspect prior records before registering.")
    mode = "rwc" if create else "rw" if write else "ro"
    db = sqlite3.connect(path.as_uri() + "?mode=" + mode, uri=True, timeout=30)
    db.row_factory = sqlite3.Row
    try:
        db.execute("PRAGMA foreign_keys=ON")
        with db:
            if write:
                db.execute("BEGIN IMMEDIATE")
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version == 0 and create:
                require(not db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall(),
                        "Unrecognized registry; preserve and inspect it.")
                for statement in SCHEMA:
                    db.execute(statement)
                db.execute("PRAGMA user_version=1")
            else:
                require(version == 1, "Unsupported registry version; preserve and inspect it.")
            yield db
    finally:
        db.close()


def has_records(root):
    root = Path(root)
    return root.is_dir() and ((root / "memory.sqlite3").is_file() or (root / "STATE.md").is_file())


def session(db, ident):
    row = db.execute("SELECT * FROM sessions WHERE id=?", (ident,)).fetchone()
    require(row is not None, f"Unknown session: {ident}")
    item = dict(row)
    item["records_available"] = has_records(item["root"])
    return item


def binding(db, ident, context):
    text_value(context, "context")
    require(session(db, ident)["records_available"], "Session records are missing; do not bind an empty replacement.")
    db.execute("INSERT INTO bindings VALUES (?,?,?) ON CONFLICT(context_id) DO UPDATE SET "
               "session_id=excluded.session_id, updated_at=excluded.updated_at", (context, ident, now()))


def register(project, data, context=None):
    require(isinstance(data, dict), "Session input must be an object")
    project = Path(project).resolve()
    root = Path(text_value(data.get("root"), "root"))
    root = (root if root.is_absolute() else project / root).resolve()
    require(root.is_relative_to(project), "Session must be inside this project; use the original project for cross-project resume.")
    require(has_records(root), f"No research records at {root}; registering never initializes research memory.")
    title = text_value(data.get("title"), "title")
    interest = text_value(data.get("interest"), "interest")
    status = data.get("status")
    require(status is None or (isinstance(status, str) and status in STATUSES), "Invalid research status")
    with connect(project, write=True, create=True) as db:
        old = db.execute("SELECT * FROM sessions WHERE root=?", (str(root),)).fetchone()
        stamp = now()
        if old:
            ident = old["id"]
            db.execute("UPDATE sessions SET title=?, interest=?, status=?, updated_at=? WHERE id=?",
                       (title, interest, status or old["status"], stamp, ident))
        else:
            ident = "s_" + uuid.uuid4().hex[:12]
            db.execute("INSERT INTO sessions VALUES (?,?,?,?,?,?,?)",
                       (ident, str(root), title, interest, status or "SEARCHING", stamp, stamp))
        if context is not None:
            binding(db, ident, context)
        return {"created": old is None, "session": session(db, ident)}


def list_sessions(project):
    if not registry_path(project).exists():
        return []
    with connect(project) as db:
        return [session(db, row["id"]) for row in db.execute("SELECT id FROM sessions ORDER BY created_at, id")]


def selected(item, reason):
    return {"status": "selected" if item["records_available"] else "unavailable",
            "reason": reason, "session": item,
            "next": "Read SEARCH_BRIEF.md and STATE.md; check the research ledger before acting."}


def resolve(project, context=None, terms=None):
    items = list_sessions(project)
    if not items:
        return {"status": "not_found", "reason": "No registered sessions; inspect existing project records before creating one.",
                "candidates": []}
    if context:
        with connect(project) as db:
            bound = db.execute("SELECT session_id FROM bindings WHERE context_id=?", (context,)).fetchone()
            if bound:
                return selected(session(db, bound["session_id"]), "Explicit context binding; inspect any new interest before changing scope.")
    if terms:
        normalized = [normal(text_value(term, "term")) for term in terms]
        matches = []
        for item in items:
            matched = [term for term in normalized if term in normal(item["title"] + " " + item["interest"])]
            if matched:
                matches.append(dict(item, matched_terms=matched))
        if not matches:
            return {"status": "no_match", "reason": "Lexical matching only; compare these tasks semantically before creating a new one.",
                    "candidates": items}
        items = matches
    if len(items) == 1:
        return selected(items[0], "Only matching registered session")
    unfinished = [item for item in items if item["status"] != "TOPIC_FOUND"]
    if len(unfinished) == 1:
        return selected(unfinished[0], "Only unfinished matching session")
    return {"status": "ambiguous", "reason": "Use known context or compare task meaning; recency is not sufficient.",
            "candidates": items}


def bind(project, ident, context):
    with connect(project, write=True) as db:
        binding(db, ident, context)
        return {"bound": True, "context": context, "session": session(db, ident)}


def set_status(project, ident, status):
    require(status in STATUSES, "Invalid research status")
    with connect(project, write=True) as db:
        session(db, ident)
        db.execute("UPDATE sessions SET status=?, updated_at=? WHERE id=?", (status, now(), ident))
        return {"session": session(db, ident)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list")
    sub = commands.add_parser("resolve")
    sub.add_argument("--context")
    sub.add_argument("--term", action="append")
    sub = commands.add_parser("register")
    sub.add_argument("--input", required=True, help="UTF-8 JSON: root, title, interest; optional status")
    sub.add_argument("--context")
    sub = commands.add_parser("bind")
    sub.add_argument("--id", required=True)
    sub.add_argument("--context", required=True)
    sub = commands.add_parser("set-status")
    sub.add_argument("--id", required=True)
    sub.add_argument("--status", required=True, choices=sorted(STATUSES))
    args = parser.parse_args()
    try:
        if args.command == "register":
            data = json.loads(Path(args.input).read_text(encoding="utf-8-sig"))
            output = register(args.project, data, args.context)
        elif args.command == "resolve":
            output = resolve(args.project, args.context, args.term)
        elif args.command == "bind":
            output = bind(args.project, args.id, args.context)
        elif args.command == "set-status":
            output = set_status(args.project, args.id, args.status)
        else:
            output = {"sessions": list_sessions(args.project)}
        print(json.dumps(output, ensure_ascii=False, indent=2))
    except (ValueError, OSError, sqlite3.Error) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
