#!/usr/bin/env python3
"""Task-local research ledger. No network, model calls, or third-party packages."""
import argparse
import contextlib
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import unicodedata
import uuid
from datetime import datetime, timezone


VERSION = 1
STATUSES = {"queued", "active", "parked", "rejected", "found"}
KINDS = {"note", "plan", "result", "lesson", "decision", "reopen", "correction"}
IDENTITY = ("shock", "population", "outcome", "design", "period")
SCHEMA = """
CREATE TABLE candidates (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, question TEXT NOT NULL,
 identity TEXT NOT NULL, fingerprint TEXT NOT NULL UNIQUE,
 aliases TEXT NOT NULL, parent_id TEXT REFERENCES candidates(id),
 status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE events (
 id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL REFERENCES candidates(id),
 kind TEXT NOT NULL, summary TEXT NOT NULL, scope TEXT NOT NULL,
 evidence TEXT NOT NULL, next_action TEXT NOT NULL, run_id TEXT,
 status_after TEXT NOT NULL, supersedes TEXT REFERENCES events(id),
 aliases TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX events_candidate ON events(candidate_id, created_at);
CREATE UNIQUE INDEX one_plan ON events(candidate_id, run_id) WHERE kind='plan';
CREATE UNIQUE INDEX one_result ON events(candidate_id, run_id) WHERE kind='result';
CREATE UNIQUE INDEX one_correction ON events(supersedes) WHERE supersedes IS NOT NULL;
PRAGMA user_version=1;
"""


def require(condition, message):
    if not condition:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def normal(value):
    return " ".join(unicodedata.normalize("NFKC", value).casefold().split())


def nonempty(value, name):
    require(isinstance(value, str) and value.strip(), f"{name} must be nonempty text")
    return value.strip()


def aliases(value):
    require(isinstance(value, list), "aliases must be a list of strings")
    return list(dict.fromkeys(nonempty(item, "alias") for item in value))


@contextlib.contextmanager
def connect(root, write=False):
    path = Path(root).resolve() / "memory.sqlite3"
    require(path.is_file(), f"Memory not found: {path}. Locate prior records; do not silently reinitialize.")
    db = sqlite3.connect(path.as_uri() + ("?mode=rw" if write else "?mode=ro"),
                         uri=True, timeout=30)
    db.row_factory = sqlite3.Row
    try:
        db.execute("PRAGMA foreign_keys=ON")
        require(db.execute("PRAGMA user_version").fetchone()[0] == VERSION,
                "Unsupported memory schema; preserve it and inspect before changing it.")
        with db:
            yield db
    finally:
        db.close()


def initialize(root):
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    path = root / "memory.sqlite3"
    if path.exists():
        with connect(root):
            return {"memory_root": str(root), "created": False, "schema": VERSION}
    # Exclusive creation prevents a concurrent init from replacing a ledger.
    with path.open("xb"):
        pass
    db = sqlite3.connect(path)
    try:
        with db:
            db.executescript(SCHEMA)
    finally:
        db.close()
    return {"memory_root": str(root), "created": True, "schema": VERSION}


def candidate(db, candidate_id):
    row = db.execute("SELECT * FROM candidates WHERE id=?", (candidate_id,)).fetchone()
    require(row is not None, f"Unknown candidate: {candidate_id}")
    return row


def unpack(row):
    item = dict(row)
    for key in ("identity", "aliases", "evidence"):
        if key in item:
            item[key] = json.loads(item[key])
    item.pop("fingerprint", None)
    return item


def add(root, data):
    title = nonempty(data.get("title"), "title")
    question = nonempty(data.get("question"), "question")
    identity = data.get("identity")
    require(isinstance(identity, dict), "identity must be an object")
    require(set(identity) == set(IDENTITY), f"identity needs exactly: {', '.join(IDENTITY)}")
    identity = {key: nonempty(identity[key], key) for key in IDENTITY}
    fingerprint = hashlib.sha256(encode({k: normal(v) for k, v in identity.items()}).encode()).hexdigest()
    names = aliases(data.get("aliases", []))
    with connect(root, write=True) as db:
        db.execute("BEGIN IMMEDIATE")
        prior = db.execute("SELECT * FROM candidates WHERE fingerprint=?", (fingerprint,)).fetchone()
        if prior:
            return {"created": False, "candidate": unpack(prior),
                    "notice": "Exact normalized identity exists. Inspect it; this is not semantic equivalence proof."}
        parent = data.get("parent_id")
        if parent is not None:
            candidate(db, parent)
        ident, stamp = "c_" + uuid.uuid4().hex[:12], now()
        db.execute("INSERT INTO candidates VALUES (?,?,?,?,?,?,?,?,?,?)",
                   (ident, title, question, encode(identity), fingerprint, encode(names),
                    parent, "queued", stamp, stamp))
        return {"created": True, "candidate": unpack(candidate(db, ident))}


def append_event(root, data):
    cid = nonempty(data.get("candidate_id"), "candidate_id")
    kind = data.get("kind")
    require(isinstance(kind, str) and kind in KINDS, f"kind must be one of {sorted(KINDS)}")
    summary = nonempty(data.get("summary"), "summary")
    scope, next_action = data.get("scope", ""), data.get("next_action", "")
    require(isinstance(scope, str) and isinstance(next_action, str), "scope and next_action must be text")
    evidence = data.get("evidence", [])
    require(isinstance(evidence, list), "evidence must be a list")
    for item in evidence:
        require(isinstance(item, dict) and bool(item.get("path")) != bool(item.get("url")),
                "each evidence item needs exactly one of path or url")
        nonempty(item.get("path") or item.get("url"), "evidence reference")
    names = aliases(data.get("aliases", []))
    run_id, supersedes = data.get("run_id"), data.get("supersedes")
    if kind in {"plan", "result"}:
        nonempty(run_id, "run_id")
    if kind == "lesson":
        require(scope.strip() and evidence, "lesson needs an explicit scope and evidence")
    if kind == "correction":
        require(supersedes and evidence, "correction needs supersedes and evidence")
    else:
        require(supersedes is None, "only a correction may supersede an event")
    with connect(root, write=True) as db:
        db.execute("BEGIN IMMEDIATE")
        old = candidate(db, cid)
        status = data.get("status", "active" if kind in {"plan", "reopen"} else old["status"])
        require(isinstance(status, str) and status in STATUSES, f"status must be one of {sorted(STATUSES)}")
        if kind == "plan":
            require(status == "active", "a plan must leave the candidate active")
        if old["status"] in {"parked", "rejected", "found"}:
            require(kind == "reopen" or (status == old["status"] and kind != "plan"),
                    "Reopening a parked/rejected/found candidate needs a reopen event with new evidence")
        if kind == "reopen":
            require(old["status"] in {"parked", "rejected", "found"} and evidence and status == "active",
                    "reopen needs a closed/parked candidate, new evidence, and status active")
        if kind == "result":
            plan = db.execute("SELECT id FROM events WHERE candidate_id=? AND kind='plan' AND run_id=?",
                              (cid, run_id)).fetchone()
            require(plan is not None, "result needs an existing plan for this candidate and run_id")
        if supersedes is not None:
            previous = db.execute("SELECT candidate_id FROM events WHERE id=?", (supersedes,)).fetchone()
            require(previous is not None and previous["candidate_id"] == cid,
                    "supersedes must point to an event belonging to this candidate")
        ident, stamp = "e_" + uuid.uuid4().hex[:12], now()
        db.execute("INSERT INTO events VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                   (ident, cid, kind, summary, scope, encode(evidence), next_action, run_id,
                    status, supersedes, encode(names), stamp))
        merged = list(dict.fromkeys(json.loads(old["aliases"]) + names))
        db.execute("UPDATE candidates SET status=?, aliases=?, updated_at=? WHERE id=?",
                   (status, encode(merged), stamp, cid))
        return {"event_id": ident, "candidate_id": cid, "status": status}


def events_for(db, cid):
    rows = db.execute("SELECT * FROM events WHERE candidate_id=? ORDER BY created_at", (cid,)).fetchall()
    replacements = {row["supersedes"]: row["id"] for row in rows if row["supersedes"]}
    items = [unpack(row) for row in rows]
    for item in items:
        item["superseded_by"] = replacements.get(item["id"])
    return items


def pending_runs(db):
    return [dict(row) for row in db.execute("""
        SELECT p.candidate_id, p.run_id, p.id AS plan_event, p.summary, p.created_at
        FROM events p WHERE p.kind='plan' AND NOT EXISTS (
          SELECT 1 FROM events r WHERE r.kind='result'
            AND r.candidate_id=p.candidate_id AND r.run_id=p.run_id)
        ORDER BY p.created_at
    """)]


def page(items, limit, offset):
    require(1 <= limit <= 100 and offset >= 0, "limit must be 1..100; offset must be nonnegative")
    end = offset + limit
    return {"total": len(items), "offset": offset, "items": items[offset:end],
            "has_more": end < len(items), "next_offset": end if end < len(items) else None}


def recall(root, terms, limit=10, offset=0):
    terms = list(dict.fromkeys(normal(nonempty(term, "term")) for term in terms))
    require(terms, "Supply at least one term; use aliases and different economic dimensions")
    matches = []
    with connect(root) as db:
        for row in db.execute("SELECT * FROM candidates ORDER BY updated_at DESC"):
            item = unpack(row)
            history = events_for(db, item["id"])
            haystack = normal(encode(item) + " " + encode(history))
            matched = [term for term in terms if term in haystack]
            if matched:
                recent = [event for event in history if not event["superseded_by"]][-3:]
                lessons = [event for event in history if event["kind"] in {"lesson", "correction"}
                           and not event["superseded_by"]]
                relevant = [event for event in history if any(term in normal(encode(event)) for term in terms)]
                matches.append({"candidate_id": item["id"], "title": item["title"], "status": item["status"],
                                "identity": item["identity"], "parent_id": item["parent_id"],
                                "matched_terms": matched, "current_lessons": lessons[-3:],
                                "current_lesson_count": len(lessons), "recent_events": recent,
                                "matching_events": relevant[-5:], "matching_event_count": len(relevant),
                                "event_count": len(history)})
    matches.sort(key=lambda item: -len(item["matched_terms"]))
    return {"memory_root": str(Path(root).resolve()), "matching": "lexical; not semantic proof",
            "terms": terms, **page(matches, limit, offset)}


def show(root, cid, limit=20, offset=0, terms=None):
    with connect(root) as db:
        item = unpack(candidate(db, cid))
        history = list(reversed(events_for(db, cid)))
        total = len(history)
        if terms:
            normalized = [normal(nonempty(term, "term")) for term in terms]
            history = [event for event in history if any(term in normal(encode(event)) for term in normalized)]
        return {"candidate": item, "total_event_count": total,
                "event_filter": terms or [], "events_newest_first": page(history, limit, offset)}


def resume(root, limit=10, offset=0):
    with connect(root) as db:
        rows = db.execute("SELECT id,title,status,updated_at FROM candidates ORDER BY updated_at DESC").fetchall()
        counts = dict(db.execute("SELECT status,COUNT(*) FROM candidates GROUP BY status"))
        pending = pending_runs(db)
        return {"memory_root": str(Path(root).resolve()), "status_counts": counts,
                "recent_candidates": page([dict(row) for row in rows], limit, offset),
                "unfinished_operations": page(pending, limit, offset),
                "next": "Read STATE.md, inspect unfinished work, then recall relevant old candidates before new work."}


def check(root):
    root = Path(root).resolve()
    with connect(root) as db:
        integrity = [row[0] for row in db.execute("PRAGMA integrity_check")]
        foreign_keys = [tuple(row) for row in db.execute("PRAGMA foreign_key_check")]
        missing = []
        for row in db.execute("SELECT id,evidence FROM events WHERE kind!='plan'"):
            for reference in json.loads(row["evidence"]):
                if reference.get("path"):
                    path = Path(reference["path"])
                    path = path if path.is_absolute() else root / path
                    if not path.exists():
                        missing.append({"event_id": row["id"], "path": str(path)})
        pending = pending_runs(db)
        return {"structure_ok": integrity == ["ok"] and not foreign_keys,
                "integrity": integrity, "foreign_key_errors": foreign_keys,
                "missing_evidence": missing, "unfinished_operations": pending,
                "meaning": "Checks persistence and references, not correctness, complete recall, or causal identification."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, help="Existing task search directory; never a global skill directory")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("init", "check"):
        commands.add_parser(name)
    for name in ("add", "event"):
        sub = commands.add_parser(name)
        sub.add_argument("--input", required=True, help="UTF-8 JSON object")
    for name in ("recall", "show", "resume"):
        sub = commands.add_parser(name)
        sub.add_argument("--limit", type=int, default=10 if name != "show" else 20)
        sub.add_argument("--offset", type=int, default=0)
        if name == "recall":
            sub.add_argument("--term", action="append", required=True)
        if name == "show":
            sub.add_argument("--id", required=True)
            sub.add_argument("--term", action="append", help="Filter events; inspect superseded_by references too")
    args = parser.parse_args()
    try:
        if args.command in {"add", "event"}:
            data = json.loads(Path(args.input).read_text(encoding="utf-8-sig"))
            require(isinstance(data, dict), "input must be a JSON object")
            output = (add if args.command == "add" else append_event)(args.root, data)
        elif args.command == "recall":
            output = recall(args.root, args.term, args.limit, args.offset)
        elif args.command == "show":
            output = show(args.root, args.id, args.limit, args.offset, args.term)
        elif args.command == "resume":
            output = resume(args.root, args.limit, args.offset)
        else:
            output = (initialize if args.command == "init" else check)(args.root)
        print(json.dumps(output, ensure_ascii=False, indent=2))
    except (ValueError, OSError, sqlite3.Error) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
