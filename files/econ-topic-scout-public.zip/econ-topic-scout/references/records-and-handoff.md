# Records and handoff

Read this file when initializing or restoring a search, completing a candidate evaluation, or delivering a topic. Save records in the task's designated search directory; the installed skill contains methods and tools only. Follow [Research memory and resumption](memory-and-resume.md) for recovery and duplicate checks. Do not hard-code a project path, data source, or model version.

## Minimum working memory

Use a compatible existing ledger or create a local `memory.sqlite3` with the supplied tool to store candidate identities, events, and evidence references. The files below provide concise handoffs and readable summaries using the ledger's stable identifiers. Store real data and code separately. An ever-growing narrative summary is not a substitute for searchable records.

- Project index `work/econ-topic-scout/sessions.sqlite3`: register task locations, summaries, and status under the [automatic recovery rules](minimal-input-and-routing.md). Save chat bindings when reliable identifiers are available. The index does not replace the research records below.
- `SEARCH_BRIEF.md`: preserve interests, preferences, user constraints, default assumptions, and their sources. Record rounds, delivered topics, and exclusions. New instructions replace corresponding old constraints only; retain a record of corrections.
- `STATE.md`: record the absolute memory path, requirements-file reference, current round and screening level, current candidate identifier and status, latest event, unfinished operations, search starting points already covered, and one concrete next action. Reference delivered topics so they are not counted as new successes.
- `CANDIDATES.md`: provide a readable index of candidate identifiers and aliases, branch relationships, economic questions and starting points, closest literature and incremental contribution, identification, data, initial signals, the three criteria, and retention or rejection decisions. Retain references to failures and nulls, with reopening conditions. Retrieve long histories from the ledger as needed; a truncated selection is not the full candidate set.
- `SEARCH_LOG.md`: reference ledger events and actual files to show how evidence changed questions, samples, definitions, or models. Record all runs, including failures and insignificant results. Long logs may be split into sections without deleting earlier paths or evidence.
- Each analyzed candidate's folder: preserve minimum reproducible inputs and code, complete results, and key sources. Before delivery add `PRE_HANDOFF_REVIEW.md` under the [review procedure](candidate-search-and-review.md). For restricted data, document acquisition and reproduction steps instead of copying unauthorized materials.

Suggested search statuses are `SEARCHING`, `VERIFYING`, `TOPIC_FOUND`, `NOT_FOUND_YET`, and `BLOCKED`. Record candidate decisions separately as continuing, awaiting materials, or rejected. These are research-record labels and do not automatically change application goals or task statuses.

Reopening a failed candidate requires new materials, new identification grounds, or an explicit change in the user's objective, with links to the original candidate and new evidence. After changing chats, locate the same memory directory, read its state, retrieve relevant history, and reuse credible assets. Before resumption and delivery, check ledger structure, unfinished operations, and evidence paths. Repair or disclose missing records rather than guessing their contents.

## Final topic package

When a topic qualifies, save a concise `TOPIC_BRIEF.md` with the main results and reproduction entry points. For multiple rounds, use distinct directories such as `rounds/001/TOPIC_BRIEF.md`, with references in `SEARCH_BRIEF.md` and `STATE.md`. Preserve earlier deliveries. Update the index to `TOPIC_FOUND` and finish; start the next round only after a subsequent "Continue" instruction. A one- or two-page brief is sufficient, without formal manuscript formatting.

| Item | Required content |
|---|---|
| Topic in one sentence | Economic question, institutional change, and preliminary finding |
| Why it matters | Economic agents and decisions, effect magnitude, closest papers, and specific incremental contribution; state the search scope |
| Why identification is credible | Assignment process, estimand, population, treatment and inference units, key assumptions, completed diagnostics, and remaining risks |
| Data already available | Data actually obtained, versions, periods, sample, key variables, and links; distinguish acquired data from data that might be requested later |
| Preliminary results | Baseline levels, effects in natural units, intervals, unadjusted and applicable adjusted inference, and effective sample; disclose exploratory status |
| Minimum necessary checks | Threats examined, checks performed, findings, and limitations; pre-handoff review method, objections, and responses, including whether an independent context was used |
| Next-phase handoff | A few valuable deeper questions and data gaps, without executing mechanism, welfare, or manuscript development |
| Reproduction entry points | Source files, analysis code, all results, candidate identifier, memory directory, and key review or correction events |

End a successful package with an explicit decision:

"This round meets the topic-discovery objective: economic contribution, identification, and the preliminary signal satisfy the discovery-stage criteria. The topic warrants deeper research. Current results remain exploratory, subject to the assumptions and limitations stated above."

If any criterion is unmet, report `NOT_FOUND_YET` or the actual blocker instead of using the success statement. Explain what was attempted, why candidates were rejected, and the next action. The package supports a decision to develop the project; it does not guarantee publication or eventual confirmation of the result.

## A simple diagram for the user

Use a single loop like this, adapting labels to the actual research. Do not add a branch for every temporary idea.

```mermaid
flowchart TD
    A[State research interests] --> B[Search from different angles]
    B --> C[Check identification and real data]
    C -->|Pass| D[Estimate and check the initial signal]
    C -->|Fail| B
    D -->|Insufficient signal| B
    D -->|Promising signal| E[Independent review before handoff]
    E -->|Key evidence fails| B
    E -->|All three criteria hold| F[Deliver one topic and stop]
```

Make clear small repairs before abandoning a candidate; return to the search when key conditions fail. Without an independent context, change the review node to "Source review before handoff" and disclose that limitation. The diagram covers discovery only; deeper research after the stopping node belongs to a subsequent task.
