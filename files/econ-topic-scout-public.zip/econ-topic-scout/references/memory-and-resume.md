# Research memory and resumption

Read this file when starting, resuming, switching candidates, or preparing downloads or estimates. Memory relies on saved, searchable research records. Do not promise that the model always remembers every conversation. Unrecorded findings, missed aliases, and incorrect records can still cause omissions.

## One research task, one explicit memory directory

Follow [Minimal input and automatic recovery](minimal-input-and-routing.md) to locate the search directory from the current context and project index. Read effective preferences in `SEARCH_BRIEF.md` and record the directory's absolute path in `STATE.md`. Locate this same directory when resuming after context compaction or in another chat. Do not routinely require the user to provide the path or create an empty ledger merely because the current chat lacks earlier messages. Other projects and unconnected directories do not automatically share memory. When the user requests reuse across projects, explicitly connect the relevant directory rather than searching the entire private filesystem.

The [research_memory.py](../scripts/research_memory.py) tool uses only the Python standard library and stores `memory.sqlite3` in the specified search directory. It provides stable identifiers, exact-duplicate checks, keyword and alias retrieval, append-only events, unfinished-operation tracking, and corrections. Store indexes, summaries, and evidence references in the ledger; keep large datasets and full outputs in candidate folders.

The ledger is the canonical record of candidate identities, status, and events. `SEARCH_BRIEF.md` holds user requirements and deliveries by round. `STATE.md` is a short handoff note; `CANDIDATES.md` and `SEARCH_LOG.md` provide readable summaries and record entry points. Use the same candidate identifiers throughout. The project index stores locations and status hints for recovery, not research evidence. Do not overwrite ledger history with handwritten summaries. A compatible existing system may remain in use without a forced migration or competing canonical records.

When adopting the tool for earlier text records, inventory and register verifiable candidates and evidence references while retaining the original files. Mark unreviewed history as a memory gap; an empty ledger does not mean there is no history. If the script cannot run, use structured text with the same identifier, retrieval, append, and handoff rules, and disclose that tool-based checks remain incomplete.

## The retrieve, act, and writeback cycle

1. **Recover the current position.** Read `SEARCH_BRIEF.md` and `STATE.md`. Run `resume` to inspect active candidates, recent changes, and unfinished operations. Reconcile the index, state, and actual events using saved files and any running processes rather than guessing which state is correct. A new round after delivery retains the ledger and leaves delivered candidates marked `found`; do not reopen them to present old work as a new discovery.
2. **Check prior work before investing.** Before registering a candidate, downloading data, or starting an estimation round, run `recall` with full policy names, abbreviations, aliases in relevant languages, datasets, and behavioral keywords. Open relevant candidates with `show` and compare shock, population, outcome, design, and period. Exact signatures detect identically specified identities only. A keyword miss does not prove novelty. Check total matches and subsequent pages rather than treating the first few records as the entire history.
3. **State what is new.** Record whether this is a first investigation, continuation, neighboring question, necessary reproduction, or reopening, and cite related identifiers. Reopen failed directions only with new materials, new identification grounds, or a user change to the objective. Preserve earlier failures and the evidence for reopening. Renaming a topic or changing chats does not make it new.
4. **Record operations before downloading or estimating.** Add a `plan` with a `run_id`, data version, inputs, output locations, and purpose. Then perform the work. Append a `result` for the same `run_id` when an outcome or failure is known, preserving the actual commands or code and result locations. After interruption, check the real operation state. If a process is still running, leave it unfinished; preparation or launch is not completion.
5. **Write back before switching directions.** Immediately append new facts, failures, measurement repairs, and retention or rejection decisions. For reusable lessons, record scope, evidence, and conditions for reopening. Update the short handoff before moving to another candidate rather than waiting until the final report. If writing fails, repair it or use a writable alternative and disclose the gap; do not claim memory was saved when it was not.

Retrieve existing inputs, versions, and outputs before deciding to repeat work. Reuse available files that fit the current question. For a justified reproduction, version update, or definition change, create a new operation identifier and record the rationale. Not all repetition is wasteful.

## Keep growing records searchable

- Keep only the objective, current candidate, most relevant lessons, and next action in active context. Retrieve full history from the ledger and source files when needed rather than loading it all every round.
- Use stable candidate identifiers and `parent_id` for branches. Record multilingual names, abbreviations, and earlier names in `aliases`. Store details outside the ledger fields in candidate files and reference them through `evidence`.
- Scope lessons carefully. One data version lacking official assignment does not mean every version lacks it. One insignificant candidate does not invalidate an entire field. Failure to identify an effect in a sample does not establish a true zero.
- When an earlier judgment is wrong, append a `correction` with `supersedes`, retain the original event, and identify the current judgment. Do not propagate a discredited lesson or erase the decisions that relied on it.
- Compress summaries, not original records. When reorganizing long logs, retain identifiers, events, and evidence references. Before resumption and delivery, run `check` for ledger structure, unfinished operations, and missing local evidence. Rewriting a summary does not repair missing evidence.

## Tool usage

Use an available Python interpreter. Replace `<skill>` and `<search-root>` with the actual skill folder and task search directory.

```text
python <skill>/scripts/research_memory.py --root <search-root> init
python <skill>/scripts/research_memory.py --root <search-root> add --input candidate.json
python <skill>/scripts/research_memory.py --root <search-root> event --input event.json
python <skill>/scripts/research_memory.py --root <search-root> recall --term "policy name" --term "firm entry"
python <skill>/scripts/research_memory.py --root <search-root> show --id c_...
python <skill>/scripts/research_memory.py --root <search-root> resume
python <skill>/scripts/research_memory.py --root <search-root> check
```

Use `init` only after establishing that a new task directory is needed. Other commands report missing memory instead of silently creating an empty ledger. `recall` and `show` support `--limit` and `--offset`; `show --term` filters a candidate's event history. Inspect `superseded_by` on retrieved events and follow correction identifiers until reaching the current judgment. The small number of events and lessons in a summary does not represent the full history. Retrieval is lexical, not proof of semantic equivalence or novelty.

Candidate JSON requires `title`, `question`, and an `identity` object containing exactly five nonempty strings: `shock`, `population`, `outcome`, `design`, and `period`. Mark unresolved fields explicitly as "undetermined." Optional fields are an `aliases` array and `parent_id`. An identical normalized identity returns the existing identifier without overwriting earlier conclusions. Create a separate candidate for a substantively new economic question and link it to related work; do not merge different questions through aliases.

Event JSON requires `candidate_id`, `kind`, and `summary`. Optional fields are `scope`, `evidence`, `next_action`, `run_id`, `status`, `supersedes`, and `aliases`. Event kinds are `note`, `plan`, `result`, `lesson`, `decision`, `reopen`, and `correction`. Candidate statuses are `queued`, `active`, `parked`, `rejected`, and `found`. `evidence` is an array of objects containing a `path` or `url`, optionally with version metadata. Relative paths resolve from the search directory. A `lesson` needs scope and evidence; a `correction` needs the superseded event and evidence; a `reopen` needs new grounds. New execution or reproduction uses a new `run_id`; correction of a prior record uses `correction`.

The tools check record structure and operation continuity. They do not determine whether contributions, causal assumptions, or lessons are correct. Delivery still requires the three discovery criteria and pre-handoff review; complete records do not substitute for empirical evidence.
