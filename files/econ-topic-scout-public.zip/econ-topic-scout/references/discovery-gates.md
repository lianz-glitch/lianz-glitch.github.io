# Discovery-stage checks

For promising candidates, read and apply only the checks relevant to the design. These are minimum requirements for a credible preliminary discovery. Institutions and data determine the diagnostics; do not turn them into a universal manuscript-review checklist.

## Economic contribution

Explain in three sentences which economic agents and choices are affected, what the finding says about incentives, constraints, or market functioning, and what it adds to the closest research. Mechanisms may remain untested, but the economic question must be concrete. Prefer credible identification opportunities paired with new behavioral margins. A different location, another mechanical indicator, or a restatement of an accounting identity does not establish a contribution.

Check a few of the closest papers in full, or primary materials sufficient to verify their designs and conclusions. Record the search date and scope, existing findings, and the specific addition. The policy itself need not already have a paper; new events can provide useful identification. Statistical significance and a potential journal tier do not substitute for economic importance.

## Institutions and measurement

Distinguish announcement, eligibility determination, actual treatment, outcome measurement, and data-release dates. Investigate history insofar as it changes identification or interpretation. Verify the official assignment variable and the contemporaneous version of the rules. Public naming, candidate eligibility, and formal regulatory treatment are not interchangeable.

Verify the analysis population and key record linkages. Distinguish firms, facilities, administrative identifiers, and ultimate owners; certification, first operation, and investment decisions; period flows and end-of-period stocks; reporting-row changes and actual behavior. Resolve ambiguity about entities or dates when it affects the result.

A missing report is not a zero, and an unobserved transaction is not evidence that no transaction occurred. Do not select the sample using post-policy entry, survival, reporting, or eligibility and then claim to identify effects for a fixed population without qualification. For an unconditional market-level contribution, retain structural zeros in markets with no activity while treating genuine missingness separately.

Check support and precision in the actual sample and key events. Do not impose a universal sample-size, coverage, or power threshold. Very few events, few effective treatment clusters, or severe imbalance may require exact inference, a narrower estimand, or abandoning the candidate. A large row count does not solve these problems.

## Checks by identification design

| Design | Facts to verify at discovery stage | Unacceptable shortcuts |
|---|---|---|
| Random assignment or randomized policy | Original assignment lists, strata, and assignment units; exclusion or separate treatment of nonrandom additions; compliance and ITT definition; baseline conditions, differential missingness, and obvious spillovers; inference at the assignment level | Treating facility rows as independent randomization units; selecting comparable units by post-treatment status; assuming randomization guarantees unbiased outcome measurement |
| RD or eligibility threshold | The score actually used, threshold, exceptions, and first stage; local support, discrete scores and ties; manipulation and pre-policy outcomes or covariates; reasonable local specifications | Substituting a convenient proxy score for official assignment; inferring potential-outcome continuity from an eligibility jump; shifting the window to obtain significance |
| DID or staggered policy | Announcement and implementation dates, clearly affected units and controls, comparable measurement, and pre-policy support; anticipation and concurrent differential shocks; estimands and estimators compatible with heterogeneous effects | Claiming that a pretrend p > 0.05 proves parallel trends; inappropriate use of already-treated controls; interpreting changed reporting coverage as changed behavior |
| IV | Relevance, weak-instrument inference, institutional grounds for exogeneity, exclusion, and any required monotonicity assumption; the local effect being estimated | Treating a strong first stage as proof of identification; ignoring direct channels from the instrument to the outcome |
| Other natural experiments | The assignment process, counterfactual, economic object, and main confounders; diagnostics tied to that process | Using labels such as "exogenous shock" or "natural experiment" in place of evidence |

Data cannot prove every identifying assumption. An acceptable discovery-stage conclusion states that, under specified assumptions, no fatal obstacle to developing the topic has been found, and lists the most important remaining risks.

## Preliminary signal and minimum credibility checks

Before estimation, explain why the small set of core outcomes matters economically, how each is defined, the baseline specification, and appropriate inference. Record which information has already been examined. A plan written after exploration cannot retroactively make that exploration prospective.

For signals meeting the screening level, at minimum verify that saved inputs and code reproduce the estimate, units and baseline levels are correct, and the most obvious alternative data explanations have been checked. Choose sensitivity checks for the largest concrete threats rather than requiring a fixed number of tests.

Express effects in natural units against relevant benchmarks. A percentage-point increase in a share differs from percentage growth. A large proportional change in sparse entry can correspond to a very small absolute change. Present confidence intervals, inference methods, and the effective sample with the results.

Record unadjusted and applicable adjusted inference, distinguishing discovery screening from confirmation. Do not change test sidedness, sample exclusions, winsorization, transformations, event windows, or inference methods to pass a threshold. Explain the evidence behind necessary repairs and preserve complete results before and after each repair.

Full mechanism, welfare, and heterogeneity analyses are not prerequisites for handoff. Significance in one group and insignificance in another does not establish a between-group difference. A ratio change does not identify which component caused it. Changes across institutional periods do not automatically identify the separate effects of each policy component.

Preserve the economic meaning of precise nulls and valuable measurement findings. If the user still seeks a topic with a significant preliminary signal, move to other economically motivated candidates. Do not repeatedly reopen failed candidates without new data or an identification rationale.
