# Candidate search and pre-handoff review

Read the first section when generating or replenishing candidates. Read the second when a candidate has passed preliminary empirical screening and is ready for delivery. These procedures support the three discovery criteria without adding a paper-development phase.

## Generate candidates from distinct starting points

Build a small set of substantively different economic questions. Select starting points relevant to the field. Do not require a fixed count per category or finish every candidate before delivering a qualifying one.

| Starting point | Question to ask | Avoid |
|---|---|---|
| Economic puzzles | Which sourced fact does not fit existing explanations? | Presenting a conjecture as an observed fact |
| Institutions and incentives | Which actual rule, experiment, or eligibility change supports a credible comparison? | Listing policy names without assignment details |
| Data and measurement opportunities | What can new data, feasible linkages, or measurement repairs answer that existing information cannot? | Claiming a contribution merely because the data are new |
| Economic agents and behavioral margins | Which economically motivated decisions remain unexplained in this setting, such as entry, pricing, organization, or quality? | Cycling through outcomes without an economic rationale |
| Connections across fields and boundary conditions | Can reasoning from another field yield a different prediction or reveal conditions under which a conclusion changes? | Changing only terminology, geography, or years |

Before downloading data or estimating a new candidate, follow [Research memory and resumption](memory-and-resume.md) to retrieve aliases, earlier questions, failures, and corrections. A candidate card records its stable identifier and related earlier identifiers, question and agents, starting point, closest literature and incremental contribution, possible identification, actual data access, largest risk, and abandonment condition. Separate source-supported facts from hypotheses. For the most promising candidates, articulate at least one serious competing explanation to check. Full mechanism identification is not required now.

If every candidate is a near-duplicate question about the same shock, check whether other evidence-backed starting points have been missed before ranking. Respect the user's policy or data restrictions and seek distinct economic questions within that scope. Do not expand into unrelated fields without authorization or search further merely to demonstrate diversity once a candidate qualifies.

Abandonment conditions should be verifiable: official assignment cannot be recovered, timestamps do not distinguish pre-treatment from post-treatment observations, the closest paper already answers the same question, or the signal disappears after a necessary measurement repair. "Try another specification if insignificant" is not an adequate condition.

Turn failures into constraints for the next round. If proxy scores cannot reconstruct official assignment, prioritize events with original assignment lists rather than carrying the same defect into another policy. Reuse credible data and institutional knowledge, but require an economic rationale, definitions recorded before estimation, and complete results for each new question. Do not add weak candidates to inflate the count.

## Pre-handoff independent review

Conduct one focused review of a candidate ready for delivery to determine whether the original three criteria actually hold. Base the review on sources and reproducible results, not another model's approval.

1. **Choose a feasible review method.** If independent subagents are available and authorized, use a fresh context that did not participate in the candidate's analysis and does not inherit the proposer's full conversation. Otherwise, the current model must revisit original sources, data, and results claim by claim and disclose: "Same-context source review; independent-context review was not performed." Adopting a different persona is not independence. Do not stall indefinitely because a subagent is unavailable; a topic meeting all three discovery criteria may be delivered with that limitation disclosed. Independent-context review is distinct from independent-sample confirmation.
2. **Provide neutral evidence.** Supply the user objective, research question, estimand, claims to verify, closest literature, original institutional materials, real-data documentation, code entry points, all executed results, and exploration history. Retain failed results and specification changes. Omit the lead analyst's acceptance verdict, self-rating, and persuasive topic summary. Identify missing materials instead of asking the reviewer to guess.
3. **Focus on claims that could overturn the case for the topic.** Use the questions below to revisit sources, inspect relevant code, or reproduce key estimates when needed. Run only checks that affect the discovery-stage decision; do not start another open-ended topic search or develop a full paper.

| Review area | Questions for the reviewer |
|---|---|
| Contribution | Has the closest research already answered the question? Does the addition concern economic behavior, constraints, or market functioning rather than relabeling? |
| Identification | Do original assignment, treatment timing, and measurement timing support the claimed estimand? Are selection, comparison-group, or inference-unit problems unresolved? |
| Measurement and signal | Can saved materials reproduce the numbers? Are magnitude and uncertainty correct? Have the strongest classification, reporting, or outlier explanations been checked? |
| Search history | Does the ledger retain insignificant results, failures, specification changes, and corrections? Were similar earlier candidates missed or reopened without justification? Is the exploratory status disclosed at handoff? |

4. **Give an evidence-based verdict.** For each claim, distinguish "supported," "insufficient evidence," and "contradicted," with source or result locations. Recommend "deliver," "repair and reassess," or "reject." Do not pass a candidate on impression when key evidence is missing.
5. **Act on the findings.** Repair fixable material problems and recheck affected claims only. Reject an unfixable fatal flaw and continue with another candidate. Unexplored mechanisms or an unwritten manuscript alone do not invalidate a discovery-stage topic. Resolve disagreements through primary evidence; do not replace reviewers repeatedly until one agrees.

Save a concise `PRE_HANDOFF_REVIEW.md` in the candidate folder with the review method, materials checked, key objections, evidence locations, responses, final verdict, and remaining limitations. A bare "passed" is insufficient. Once all three criteria hold, hand off the topic rather than opening an indefinite review loop.

## Methodological sources

These sources informed the workflow and are not runtime dependencies. The user's objective and this skill's completion criteria govern the task.

- [econ-research-os brainstorm module](https://github.com/RyanPiao/econ-research-os/blob/main/skills/econ-think/brainstorm.md): generating candidates from multiple research starting points.
- [Good Question for Economics](https://github.com/lishn6/awesome-ai-econ-research-writing/blob/main/skills/good-question/SKILL.md): specifying economic questions, competing explanations, and abandonment conditions.
- [Pedro Sant'Anna's research-ideation module](https://github.com/pedrohcgs/claude-code-my-workflow/blob/main/.claude/skills/research-ideation/SKILL.md): verifying key claims against sources in an independent context.
