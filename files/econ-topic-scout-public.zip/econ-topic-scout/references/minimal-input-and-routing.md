# Minimal input and automatic recovery

Read this file when actually starting or resuming a topic search. The user needs only to state an interest or say "Continue." The skill handles task location, existing preferences, the search loop, recordkeeping, and delivery. Do not start research from interests mentioned while discussing the method, editing the skill, or requesting example prompts.

## Interpret the two input types

| User input | Default action |
|---|---|
| "I am interested in labor economics; help me find a topic," or a similarly short research direction | Recover the same task's constraints or create a new search; turn the interest into economic questions and begin |
| "I like entry, competition, and firm organization" | Save the preference in the current task and rerank candidates; distinguish preferred directions from mandatory exclusions |
| "Continue," before a qualifying topic has been found | Recover records, check unfinished operations, and resume the saved next action; move to another candidate after failure |
| "Continue," after a topic was delivered | Start another round in the same search memory, retain preferences and all history, exclude substantive duplicates of delivered topics, and stop after one more qualifying topic |
| "Develop the topic we just found" | Move to a subsequent research task rather than applying this skill's discovery-stage stopping rule |

Interpret equivalent requests in the user's language; English examples are not mandatory trigger phrases. For a new direction, determine whether it adds to, corrects, or explicitly replaces the current task. An explicit move to an incompatible field creates another task while retaining old records. Do not rewrite the previous task's goals and failures as if they concerned the new field. If "Continue" refers to different ongoing work, do not redirect it into topic discovery.

## A new user starts without personal background

The distribution contains method instructions, reference rules, interface metadata, and tools. It contains no author project context, default field, completed-topic list, task index, or research ledger. Examples illustrate usage and must not become a new user's preferences.

On first use, if the project has no real prior records, initialize `SEARCH_BRIEF.md` and an empty ledger from the user's stated interest. The user need not reconstruct the author's history or prepare a preference file. Policies, datasets, and candidates emerge from subsequent research. Leave unspecified regions, journals, and exclusions unspecified, and distinguish methodological defaults from personal choices.

`project-context.json` is optional. Its absence is not an error or a blocker. Inherit only project background that the current user is explicitly continuing. Repository examples, test data, publisher descriptions, and other people's records are not automatically this user's preferences. Restore earlier work only when that work is explicitly connected to the task. Build preferences and research history from actual conversations and operations, saving them in the user's project rather than the distribution.

## Built-in defaults and preferences

- Seek one topic per round with a clear economic contribution, credible identification, and a meaningful preliminary signal from real data. Follow `SKILL.md` for screening and exploratory disclosure; do not introduce another threshold here.
- Default to public or already authorized data. Do not demand a preference form when region, journal, budget, or method is unspecified. Choose a feasible starting point and record it as a working choice, not a permanent user constraint.
- Autonomously perform searches, data acquisition, estimation, necessary repairs, and pre-handoff review. If a candidate fails, record why and repair it or change candidates. Do not ask approval for every next step. Continue within current resource limits; request input only for actual permissions, costs, or uniquely necessary missing information.
- Preserve explicit preferences, existing topics, exclusions, and later corrections with their sources. New instructions override only conflicting parts. One insignificant result, a defect in one data version, or a strategy chosen by the model must not become a user preference.
- Only `TOPIC_FOUND` means a round is complete. Save the next action when execution stops. Skill instructions alone do not wake a background process.

## Automatic location: users usually need no paths

Use the current project root and the fixed entry point `work/econ-topic-scout/`. `sessions.sqlite3` indexes search locations only. Optional `project-context.json` stores sourced project background. Candidates, data, and estimates remain in their respective search directories. Without a project, use the current task's writable working directory rather than searching the entire private filesystem.

1. Prefer a task directory already established in the conversation. Verify that real records exist and register it with [search_registry.py](../scripts/search_registry.py), so location does not depend on retaining a long conversation. Save a chat binding if the environment provides a reliable identifier; otherwise omit it rather than inventing one from the title.
2. If no directory is established, run `resolve`. A binding for the same chat takes priority; otherwise use the unique unfinished task. If none is unfinished, a unique delivered task can support the next round. When the current search is known to be complete, retain its directory rather than jumping to an unfinished task from another chat.
3. If several tasks could fit, use `resolve --term`, task summaries, and context for semantic matching. The tool matches words only. Select and bind when the evidence is sufficient. Do not guess by last-modified time or treat a keyword miss as proof of a new direction.
4. A missing index does not imply missing history. Read project background and earlier records referenced by the conversation. If necessary, search within known research directories in the current project for `STATE.md` or `memory.sqlite3`, excluding test fixtures, validation folders, skill copies, and backups. Verify and register the original task directory without moving or clearing the ledger. Do not register every candidate folder as a separate search task.
5. Only after establishing that this is a new search, create `work/econ-topic-scout/searches/<date-direction-short-id>/`, write `SEARCH_BRIEF.md` and `STATE.md`, initialize the memory tool, and register the task. For an isolated "Continue" with no known interest, or several indistinguishable tasks, ask one necessary direction or task-selection question first. Do not invent an objective to avoid asking.

If indexed records are missing or damaged, identify the gap and look for their known original location. Do not silently create an empty task with the same name. Different projects, computers, and AI tools do not share memory merely by using the same skill name; they need access to the original records or a migrated index.

## Recover and write back

After locating the task, read `SEARCH_BRIEF.md` and `STATE.md`, then follow [Research memory and resumption](memory-and-resume.md) to run `resume`, `check`, and relevant history retrieval. Recover effective constraints, the current round, delivered topics, unfinished operations, relevant corrections, and the next action. Then perform the next useful step rather than merely announcing that recovery succeeded.

`SEARCH_BRIEF.md` is the canonical record of durable task requirements: interests, preferred behavioral margins, user constraints and sources, explicit exclusions, default assumptions, round numbers, and each round's delivery references. If older records lack it, reconstruct what can be verified from the conversation or state and mark unknowns. Keep `STATE.md` short and link to the brief. Update preferences and deliveries promptly; date corrections and explain which earlier constraints are no longer effective. Save each round's deliverables in a separate directory, preserving earlier packages and all candidates.

`project-context.json` contains only background, existing research, and record entry points that explicitly belong to the project and can be reused across its tasks. Create it only when needed. Temporary task choices are not global personal preferences. Do not store user research records in the installed skill folder or automatically rewrite the skill's methods.

Register or update the index when creating a task, changing its binding, or reporting a new stage. Index status helps locate work; scientific judgments rest on the ledger, state files, and actual evidence. If multiple chats access the same memory, check for unfinished execution and reuse or take over existing operations instead of starting duplicate download or estimation batches. A status-only request does not authorize new work.

## Index tool usage

The model supplies these parameters; users need not type commands or directories.

```text
python <skill>/scripts/search_registry.py --project <project-root> resolve [--context <reliable-chat-id>]
python <skill>/scripts/search_registry.py --project <project-root> resolve --term labor --term employment
python <skill>/scripts/search_registry.py --project <project-root> list
python <skill>/scripts/search_registry.py --project <project-root> register --input session.json [--context <reliable-chat-id>]
python <skill>/scripts/search_registry.py --project <project-root> bind --id s_... --context <reliable-chat-id>
python <skill>/scripts/search_registry.py --project <project-root> set-status --id s_... --status NOT_FOUND_YET
```

Registration JSON contains `root`, `title`, and `interest`, with optional `status`. `root` must be an existing search directory within the project containing `memory.sqlite3` or a legacy `STATE.md`. Registering the same directory returns its existing identifier; omitting status preserves its current status. For explicit cross-project resumption, use the original project's index rather than silently connecting unrelated directories to the current project. Results are `selected`, `ambiguous`, `not_found`, `no_match`, or `unavailable`. Act only after an evidence-based selection. Reading a missing index does not create one.
