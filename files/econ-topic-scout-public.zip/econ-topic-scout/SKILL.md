---
name: econ-topic-scout
description: "Find an empirically promising economics paper topic from a short statement of research interests, or resume an existing topic search when the user says continue. Automatically locate project research records, recover preferences, search literature and institutions, acquire real data, check causal identification, and estimate preliminary effects. Stop after one topic meets contribution, identification, and initial-signal criteria. Use for economics topic discovery and causal-shock searches; discussing or editing the skill is not a request to launch research, and later paper development is separate."
---

# Economics Topic Scout

Start from broad economics interests and autonomously search, screen, acquire data, and run the necessary preliminary estimates. The default goal is **one topic worth developing into a research project**. Once all three discovery criteria are met, deliver a topic package and stop.

This is a topic-discovery task. Full mechanism identification, welfare analysis, heterogeneity extensions, comprehensive robustness exercises, structural modeling, and manuscript writing are not completion requirements. Resolve measurement or identification problems that materially affect the credibility of the preliminary result before delivery.

## Completion criteria: all three must hold

| Criterion | Required evidence | Insufficient evidence |
|---|---|---|
| Economic contribution | Identify the economic agents, their decisions, the tradeoff or market-functioning question, and the insight added to the closest literature; the effect size must matter | A new policy name, an unstudied location, a mechanical indicator change, or a tiny significant coefficient |
| Credible identification and usable real data | Verify the institution and assignment process, treatment and inference units, measurement and support in actual data, and key design-specific diagnostics; leave no unresolved fatal flaw | Merely naming DID, RD, or RCT; using the wrong score or date; dismissing post-treatment selection or missing reports |
| A meaningful preliminary empirical signal | Run actual estimates that meet this round's screening criterion; report magnitude, uncertainty, appropriate inference, and minimum credibility checks against the main threats | Simulations alone, data availability, expected signs, or results driven by coding errors, isolated outliers, or unjustified specification choices |

Credible identification means passing discovery-stage checks under explicit assumptions. Do not claim that every identifying assumption has been proved. Finding a topic does not establish a complete paper.

## Start or resume

Distribute general research methods and tools, without preset research interests, existing topics, exclusions, or results belonging to the author or other users. Having no history is a normal starting point: create task-specific memory from the new user's stated interest. Example fields are not default preferences. Existing records belong to the research project the current user is continuing. Distribute only the method files in the skill folder; keep project context, task indexes, preferences, data, and execution records in their respective projects.

Normal use requires only a short statement of research interests or "Continue." On first use and resumption, read [Minimal input and automatic recovery](references/minimal-input-and-routing.md), locate the project task, recover saved preferences and research memory, and act. Do not routinely ask the user to repeat a long prompt, memory path, or completion criteria. Discussion or editing of the skill does not start a topic search.

New instructions override the corresponding old preferences; unchanged constraints remain in force. Default to public or already authorized data and work autonomously within available resources toward one topic meeting all three criteria. Do not assume an AER/top-five target, a fixed region or model, or a background schedule. The absence of a named policy, identification method, or dataset is not a reason to ask for clarification; search for and verify them.

"Continue" resumes unfinished searching when no qualifying topic has been found. If the previous round reached `TOPIC_FOUND`, retain the direction and preferences, exclude already delivered topics, and start another discovery round that stops after one topic. Develop a delivered topic further only when the user explicitly requests that phase. Do not begin another round immediately after delivery without a new instruction.

## Retrieve and update memory

Before a new direction, download batch, or estimation round, retrieve records about the same policy, data, population, and behavior. Compare their economic meaning and state what is new. Use the [memory tool](scripts/research_memory.py) or a compatible existing ledger to preserve stable candidate identifiers, aliases, branch relationships, complete events, and evidence references. A keyword miss does not establish that a direction has never been tried.

Record a plan before acting and the result after completion or failure, before changing candidates. Check unfinished operations after an interruption. Scope new lessons and attach evidence; append corrections when earlier judgments are overturned, retaining the original records. The project index stores task locations, `SEARCH_BRIEF.md` stores preferences, and the ledger stores evidence history. Follow [Research memory and resumption](references/memory-and-resume.md) for retrieval and writeback. After context compaction or a change of chat, load relevant history only. Installing the same skill does not automatically share records across projects.

## Search and validation loop

1. **Generate candidates from distinct starting points and rank them using evidence.** When starting or replenishing the search, use the candidate-generation section of [Candidate search and pre-handoff review](references/candidate-search-and-review.md). Select relevant starting points from economic puzzles, institutional changes, data opportunities, behavioral margins, and connections across fields. Prioritize credible identification opportunities that answer valuable new economic questions. Merely changing a location, year, or outcome is insufficient. For promising candidates, record a contribution sentence, closest literature, possible identification, data access, largest risk, and abandonment condition. Rank by contribution and feasibility. Do not turn "not found in the search" into "nobody has studied this." Do not delay a qualifying topic to fill a diversity quota.
2. **Verify institutions, identification, and data in practice.** Obtain the real materials needed for a minimum viable analysis of the most promising candidate. Check assignment, dates, units, linkage, missingness, coverage, and sample support. Read only the relevant [Discovery-stage checks](references/discovery-gates.md). Resolve issues that would make the estimate uninterpretable before examining effects. Record fatal gaps and move to another candidate; complete reasonable small repairs directly.
3. **Run an economically motivated preliminary estimation round.** Before estimation, record the question, a small set of core outcomes, estimand, sample, inference, and screening criterion, together with information already examined. Match the method to the assignment process and outcome type. Express effects in interpretable economic units and report baseline levels, sample sizes, intervals, and unadjusted and applicable adjusted inference.
4. **Perform minimum credibility checks on the preliminary signal.** Reproduce the main estimate, verify the raw sources of key variables, and check the threats most likely to create a false signal, such as placebo policy dates, outliers, classification repairs, or reasonable alternative definitions. Let concrete threats determine the checks; do not run a fixed, extensive regression checklist. Repair substantive errors and disclose material dependence on particular choices.
5. **Review once before handoff.** For a candidate ready for delivery, follow the [review procedure](references/candidate-search-and-review.md) to verify the key evidence on contribution, identification, and the initial signal. Use a reviewer who did not participate in the analysis when an independent context is available and authorized. Otherwise disclose a same-context source review. Repair issues that would invalidate the case for developing the topic; do not add full mechanism analysis or manuscript review to the completion criteria.
6. **Deliver or continue searching.** If all three criteria still hold after review, enter `TOPIC_FOUND` and stop. Otherwise choose a small repair, a neighboring question with a new economic rationale, or another candidate. After each rejection, record the constraint that the failure adds to the next round and rerank candidates to avoid repeating the same infeasible design. Do not deliver statistically significant but economically weak findings. Preserve candidates with credible designs but no required signal without declaring success. Do not repeatedly change samples, outcome definitions, or models to preserve significance.

## Interpreting exploratory signals

Use the user's screening level when specified. Otherwise, before the first estimate, record **an unadjusted two-sided p < 0.10 under design-appropriate inference** as the default discovery signal threshold. Distinguish the 5% and 10% levels. This default determines when a lead warrants investigation; it does not replace economic importance, measurement, identification, or sensitivity assessment, and is not a confirmatory standard for a finished paper.

Preserve every result, specification, and retention or rejection rationale from the round. Report multiple-testing results for the declared outcome family when applicable. Later outcome families, samples, or questions suggested by observed results remain exploratory. Within-family adjustments do not cover the entire adaptive topic search, and nominal p-values do not represent the search-wide error rate.

If the unadjusted signal passes but adjusted inference is weaker, an exploratory topic may be delivered with that limitation explicitly disclosed, provided economic importance, identification, and minimum credibility checks genuinely hold. Do not describe it as a confirmed effect. A signal that is unstable under key reasonable definitions, depends on unjustified choices, or reflects obvious measurement error cannot reach `TOPIC_FOUND`. Independent-sample confirmation can be listed for the next phase; this skill need not complete paper-level validation first.

Failure to detect an effect, ruling out important effects, and inability to identify an effect are different conclusions. Preserve them. When the user is seeking a significant preliminary signal, do not substitute a null result for achieving that objective.

## Stopping and handoff

At `TOPIC_FOUND`, complete the concise package in [Records and handoff](references/records-and-handoff.md) and finish. Deliver the question, contribution, identification, real data, preliminary results, key checks, and remaining assumptions. State whether the pre-handoff review used an independent context. List only a few valuable questions for deeper research without executing them.

For example, a topic can be handed off once the actual assignment of a randomized policy has been verified, firm-entry measurement has been repaired as needed, the preliminary signal remains meaningful, and the economic contribution is clear. Further mechanism identification, long-term outcomes, or welfare analysis belongs to the next phase. A decomposition needed to rule out a fatal measurement problem still belongs before handoff. This example illustrates the stopping boundary, not a preferred research field.

Normally continue to the next candidate after failure without awaiting approval at each stage. At the user's resource boundary or the current execution capacity, save `NOT_FOUND_YET` and a concrete next action that can be resumed. If all reasonable candidates face unresolved, externally blocking data or identification gaps, report `BLOCKED` and what would resolve them. Attempt counts, download volume, and polished plans are not evidence that a topic has been found.

Progress reports should explain what is being tested, what has been learned, and why to continue or abandon a direction. Explain the final discovery with one simple flowchart or a one-page topic card, not a complex project-wide research tree. Respect the current user and environment when choosing a model; do not hard-code a model name. Use review methods that are actually available and authorized, and never fabricate an independent review.
