# Evidence acceptance gates

| Gate | Accept only when | Common failure |
|---|---|---|
| Identity | Source refers to the target physical/legal unit in the relevant period | Same chain, adjacent suite, mailing address, or reused identifier |
| Definition | Concept, population, unit, and reporting category match | Authorized capacity substituted for operating capacity; FTE substituted for headcount |
| Time | Observation or exact reporting interval meets the contract | Current webpage, release year, planned completion, or fiscal year treated as actual historical time |
| Authority and traceability | Original record or appropriately qualified evidence can be located | Search snippet, unsupported summary, fabricated source coordinates |
| Consistency | Identities, totals, revisions, and chronology reconcile | Double-counted subtotals, overlapping reports, impossible date ordering |
| Integration | Patch has deterministic keys, lineage, and a documented release | An approved candidate silently presented as adopted manuscript data |

## Difficult cases

**Zero:** Require a direct numeric zero, an applicable documented source-encoding rule for a valid report, an exact identifying accounting constraint, or a documented structural zero under the population definition. Specify which. Suppression, absence, and closure in a different year do not qualify.

**Report periods:** Distinguish annual, partial operating year, fiscal year, and snapshot. Add flows only over compatible nonoverlapping periods. Do not add ratios or period averages. A deterministic reconstruction must uniquely identify the contracted period without assuming a uniform daily rate. FTE treatment depends on the specific source definition; do not impose a generic summation or annualization rule.

**Ratios and aggregates:** Align numerator and denominator to the same entity, source version, and period. Do not mix a recovered denominator with an incompatible old numerator. Report known component counts alongside partial sums. No entities can imply a zero sum, but their zero-over-zero ratio remains undefined.

**Entry:** Build the flow universe from all relevant historical releases, not only a first-versus-last stock difference. Otherwise temporary entrants disappear from the candidate universe. Verify actual operation and old-site lineage separately. Do not require a physical attribute that does not apply to a legitimate subtype of the target entity.

**Dates:** An entity formation date is an observed legal milestone, not necessarily the investment decision date. An application, a letter of intent, approval, construction start, license, ceremony, and first patient are different events. Retain bounds or unresolved status when exact dates cannot be established.

**Denominators:** Records for successful operating facilities cannot reconstruct all proposals or failed projects. A local permit archive may have excellent exact-site matches and poor statewide coverage. Search denials, withdrawals, and not-yet-open cases within a defined source universe; do not treat absence as failure.

**Official-source errors:** Prefer conflict flags and documented adjudication to automatic overwrites. A legal registry can lag ownership, a report can use a mailing address, and a submitted FTE can be implausible. The source's authority does not eliminate these errors.

## Audit priorities

Re-read exact records for all new high-risk links, zeros, dates, and source conflicts. Check a reproducible sample of routine bulk extraction against original coordinates. Report what was checked and what was not; automated checks do not establish universal accuracy. Where an independent reviewer is authorized and available, provide the contract and raw evidence without the proposed conclusion before comparison.

Coverage must distinguish: source downloaded; record found; identity matched; period eligible; value verified; candidate accepted; adopted in release; included in the analysis. These are different denominators.
