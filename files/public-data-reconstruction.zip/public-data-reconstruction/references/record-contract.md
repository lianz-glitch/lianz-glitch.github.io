# Persistent record contract

Use CSV for rectangular records, JSON for state, and immutable original source files. Other equivalent formats are acceptable if the relations and audit trail remain intact. Keep real project records outside the skill directory.

## Workspace

```
data-reconstruction/
  state.json
  contract.json
  sources.csv
  gaps.csv
  decisions.csv
  searches.jsonl
  entity-crosswalk.csv
  raw/
  derived/
  audit/
  delivery/
```

`ledger.py init` creates a minimal scaffold without overwriting existing files. Complete the contract and actual rows before substantive work. `ledger.py audit` requires them for accepted decisions, prints a machine-readable report, exits nonzero on failures, and does not modify data.

## Contract and state

Contract fields: `project_id`, `entity_unit`, `target_population`, `required_period`, `variables`, `authoritative_input`, `input_sha256`, `acceptance_rules`. Add population/assignment fingerprints, variable units, allowed report windows, selection rules, and aggregation rules where relevant. Treat changes as explicit versions, preserving the prior contract.

State fields: `status`, `contract`, `updated_utc`, `authoritative_release`, `ledger_paths`, `last_completed_action`, `next_actions`, `blockers`. Read this before resuming. List next actions as gap IDs plus source route, not vague instructions to search more. Remember rejected matches and access failures in the actual ledgers, not just a summary.

## Source ledger

One row per retrieved source version, not per website brand:

`source_id, title, publisher, url, release_date, retrieved_utc, coverage, local_path, sha256, archive_status`

`archive_status` is `archived` or `reference_only`. An archived source must have a valid local file and matching SHA-256. A reference-only source has no fabricated local file/hash; the scientific audit must document how the precise content was observed and whether the evidence is adequate. A URL alone is not factual verification. Do not store access tokens or signed private links.

## Gap ledger

`gap_id, entity_id, variable, required_period, status, missing_reason, next_action`

Status is `open`, `resolved`, or `out_of_scope`. Retain leading zeros in entity IDs. A resolved gap must have an accepted decision; out-of-scope requires a reason. Suppressed or unreleased observations are not resolved merely because their missingness is explained.

## Decision ledger

`decision_id, gap_id, source_ids, decision, value_json, provenance_class, locator, rule, entity_check, period_check, definition_check, consistency_check, reviewed_by, adopted_release, supersedes`

- `source_ids`: semicolon-separated source version IDs. Include all sources necessary for a derivation or identity proof.
- `decision`: `accepted`, `held`, or `rejected`.
- `value_json`: a JSON scalar; `0` is a value, `null` is unknown. Rejected/held proposals may retain candidate values but cannot populate the dataset.
- Checks: `pass`, `fail`, or `unresolved`. An accepted decision requires all four to pass, a non-null value, an allowed provenance class, a source, locator, rule, and reviewer.
- `adopted_release`: empty until integration is established. Being approved in a candidate audit does not establish that a paper used the value.
- `supersedes`: prior decision ID for a replacement. Preserve the prior decision and its evidence. Only the last non-superseded decision can resolve a gap.

For a real project add old value, unit, physical entity, report ID/version, source start/end, measurement date, worksheet/line/column, raw component values, formula, uncertainty, and adoption timestamp. These fields matter more than a long prose justification.

## Search and identity records

Each search records `gap_ids`, `query_or_route`, `source_scope`, `searched_utc`, `outcome`, `source_ids`, `negative_scope`, `reopen_if`. Distinguish downloaded source, not found within scope, blocked, and unreadable.

Each identity link records `entity_id`, `source_entity_id`, `relation`, `effective_start`, `effective_end`, `address_and_suite`, `source_ids`, `decision`, `reason`. Preserve ambiguous candidates instead of forcing a one-to-one mapping.

## Release gate

Produce a separately versioned candidate patch keyed by entity/period/variable. Join it to the frozen input under cardinality assertions. Record accepted insertions, corrections, rejected proposals, and unchanged values separately. Check source hashes and input immutability, build coverage, then record adoption. Never replace a newer adjudication with an older "complete" file.
