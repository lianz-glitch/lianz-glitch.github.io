"""Create and audit a public-data evidence ledger. Python standard library only."""
import argparse
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

HEADERS = {
    'sources': 'source_id,title,publisher,url,release_date,retrieved_utc,coverage,local_path,sha256,archive_status',
    'gaps': 'gap_id,entity_id,variable,required_period,status,missing_reason,next_action',
    'decisions': 'decision_id,gap_id,source_ids,decision,value_json,provenance_class,locator,rule,entity_check,period_check,definition_check,consistency_check,reviewed_by,adopted_release,supersedes',
    'entity-crosswalk': 'entity_id,source_entity_id,relation,effective_start,effective_end,address_and_suite,source_ids,decision,reason',
}
CLASSES = {'direct_observation', 'deterministic_reconstruction', 'documented_encoding_zero', 'verified_structural_zero'}


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def initialize(root):
    root.mkdir(parents=True, exist_ok=True)
    for folder in ('raw', 'derived', 'audit', 'delivery'):
        (root / folder).mkdir(exist_ok=True)
    created = []
    contract = dict.fromkeys(('project_id', 'entity_unit', 'target_population', 'required_period', 'authoritative_input', 'input_sha256'), '')
    contract.update(variables=[], acceptance_rules=[])
    state = {'status': 'NEW', 'contract': 'contract.json', 'updated_utc': datetime.now(timezone.utc).isoformat(),
             'authoritative_release': None, 'ledger_paths': [name + '.csv' for name in HEADERS],
             'last_completed_action': 'Initialize scaffold', 'next_actions': ['Complete the measurement contract and gap inventory'], 'blockers': []}
    for name, obj in [('contract.json', contract), ('state.json', state)]:
        path = root / name
        if not path.exists():
            with path.open('x', encoding='utf-8') as stream:
                json.dump(obj, stream, indent=2)
            created.append(name)
    for name, header in HEADERS.items():
        path = root / (name + '.csv')
        if not path.exists():
            with path.open('x', encoding='utf-8', newline='') as stream:
                csv.writer(stream).writerow(header.split(','))
            created.append(path.name)
    if not (root / 'searches.jsonl').exists():
        (root / 'searches.jsonl').touch(exist_ok=False)
        created.append('searches.jsonl')
    return {'created': created, 'existing_files_preserved': True}


def audit(root):
    errors, warnings, tables = [], [], {}
    for name, header in HEADERS.items():
        path = root / (name + '.csv')
        try:
            with path.open(encoding='utf-8-sig', newline='') as stream:
                reader = csv.DictReader(stream)
                missing = set(header.split(',')) - set(reader.fieldnames or [])
                if missing:
                    errors.append(f'{name}: missing columns {sorted(missing)}')
                tables[name] = list(reader)
        except (OSError, csv.Error) as exc:
            errors.append(f'{name}: {exc}')
            tables[name] = []
    indexes = {}
    for name, key in [('sources', 'source_id'), ('gaps', 'gap_id'), ('decisions', 'decision_id')]:
        index = {}
        for row in tables[name]:
            ident = row.get(key)
            if not ident or ident in index:
                errors.append(f'{name}: blank or duplicate {key}: {ident!r}')
            index[ident] = row
        indexes[name] = index
    sources, gaps, decisions = (indexes[n] for n in ('sources', 'gaps', 'decisions'))
    for ident, row in sources.items():
        if not row.get('url') or not row.get('retrieved_utc'):
            errors.append(f'{ident}: URL and retrieval timestamp required')
        if row.get('archive_status') == 'archived':
            path = root / row.get('local_path', '')
            if not path.is_file():
                errors.append(f'{ident}: archived file missing')
            elif not row.get('sha256') or digest(path) != row['sha256'].lower():
                errors.append(f'{ident}: SHA-256 mismatch')
        elif row.get('archive_status') == 'reference_only':
            warnings.append(f'{ident}: reference-only evidence requires content/locator review')
        else:
            errors.append(f'{ident}: invalid archive_status')
    superseded = set()
    for ident, row in decisions.items():
        if row.get('gap_id') not in gaps:
            errors.append(f'{ident}: unknown gap')
        prior = row.get('supersedes')
        if prior:
            if prior not in decisions or decisions[prior].get('gap_id') != row.get('gap_id'):
                errors.append(f'{ident}: invalid supersedes reference')
            if prior in superseded:
                errors.append(f'{ident}: competing replacements for {prior}')
            superseded.add(prior)
            visited, cursor = {ident}, prior
            while cursor in decisions:
                if cursor in visited:
                    errors.append(f'{ident}: cyclic decision history')
                    break
                visited.add(cursor)
                cursor = decisions[cursor].get('supersedes')
        source_ids = [s.strip() for s in row.get('source_ids', '').split(';') if s.strip()]
        for sid in source_ids:
            if sid not in sources:
                errors.append(f'{ident}: unknown source {sid}')
        if row.get('decision') not in {'accepted', 'held', 'rejected'}:
            errors.append(f'{ident}: invalid decision')
        if row.get('decision') == 'accepted':
            if not source_ids:
                errors.append(f'{ident}: accepted value has no source')
            for check in ('entity_check', 'period_check', 'definition_check', 'consistency_check'):
                if row.get(check) != 'pass':
                    errors.append(f'{ident}: {check} must pass')
            for key in ('locator', 'rule', 'reviewed_by'):
                if not row.get(key):
                    errors.append(f'{ident}: missing {key}')
            if row.get('provenance_class') not in CLASSES:
                errors.append(f'{ident}: invalid accepted provenance class')
            try:
                value = json.loads(row.get('value_json', ''))
                if value is None or isinstance(value, (dict, list)) or isinstance(value, float) and not math.isfinite(value):
                    raise ValueError('expected a non-null finite scalar')
            except (ValueError, TypeError) as exc:
                errors.append(f'{ident}: invalid accepted value: {exc}')
    live = {}
    for ident, row in decisions.items():
        if ident not in superseded and row.get('decision') == 'accepted':
            gid = row.get('gap_id')
            if gid in live:
                errors.append(f'{gid}: multiple current accepted values')
            live[gid] = ident
    for ident, row in gaps.items():
        if row.get('status') not in {'open', 'resolved', 'out_of_scope'}:
            errors.append(f'{ident}: invalid gap status')
        if row.get('status') == 'resolved' and ident not in live:
            errors.append(f'{ident}: resolved without a current accepted value')
        if row.get('status') != 'resolved' and ident in live:
            errors.append(f'{ident}: current accepted value requires resolved status')
        if row.get('status') == 'out_of_scope' and not row.get('missing_reason'):
            errors.append(f'{ident}: out_of_scope requires reason')
    try:
        contract = json.loads((root / 'contract.json').read_text(encoding='utf-8'))
        missing = [k for k in ('project_id', 'entity_unit', 'target_population', 'required_period', 'variables', 'acceptance_rules') if not contract.get(k)]
        if missing:
            (errors if live else warnings).append(f'Incomplete contract: {missing}')
        if contract.get('authoritative_input'):
            path = root / contract['authoritative_input']
            if not path.is_file() or digest(path) != contract.get('input_sha256'):
                errors.append('Authoritative input missing or changed')
    except (OSError, ValueError) as exc:
        errors.append(f'contract: {exc}')
    return {'ok': not errors, 'sources': len(sources), 'gaps': len(gaps), 'current_accepted': len(live),
            'errors': errors, 'warnings': warnings,
            'limitation': 'Checks record integrity, not factual accuracy or scientific validity.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['init', 'audit'])
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    result = initialize(args.directory) if args.action == 'init' else audit(args.directory)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result.get('ok', True) else 1)
